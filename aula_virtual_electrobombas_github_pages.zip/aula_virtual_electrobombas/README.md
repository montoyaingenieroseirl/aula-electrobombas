# Aula Virtual de Capacitación en Electrobombas Sumergibles

Sitio estático preparado para GitHub Pages.

## Archivos
- `index.html`: página del aula.
- `styles.css`: diseño adaptable a celular y computadora.
- `config.js`: fechas, videos y materiales.
- `app.js`: navegación, bloqueo por fecha y avance local.

## Periodo de acceso
En `config.js` modifica `fechaInicio` y `fechaFin` con formato `AAAA-MM-DD`. El ejemplo cuenta el 02/11/2026 como día 1 y finaliza el 30/01/2027 (día 90).

**Importante:** GitHub Pages publica archivos públicos. El bloqueo por fecha es una restricción visual del sitio, no seguridad fuerte: un usuario puede consultar los archivos o alterar el reloj de su dispositivo. No incluyas datos privados.

## Videos de YouTube
En cada módulo completa `youtubeId`. Ejemplo: para `https://www.youtube.com/watch?v=abcdefghijk`, el ID es `abcdefghijk`.

## Material PDF
Sube el PDF al repositorio, por ejemplo dentro de `materiales`, y asigna `materialUrl: "materiales/guia.pdf"`.

## Publicación
1. En GitHub crea un repositorio llamado `aula-electrobombas`.
2. Para GitHub Pages gratuito, configura el repositorio como público.
3. Sube `index.html`, `styles.css`, `config.js`, `app.js` y `README.md` a la raíz del repositorio.
4. Entra a **Settings → Pages**.
5. En **Build and deployment**, elige **Deploy from a branch**.
6. Selecciona la rama `main` y carpeta `/ (root)`, luego pulsa **Save**.
7. Espera la publicación. La dirección será similar a `https://TU-USUARIO.github.io/aula-electrobombas/`.

El avance de módulos se guarda solo en el navegador de cada participante; no se envía a un panel del administrador y no se sincroniza entre dispositivos.
