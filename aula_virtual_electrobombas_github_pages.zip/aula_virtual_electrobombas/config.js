// EDITA AQUÍ LAS FECHAS, LOS VIDEOS Y LOS MATERIALES.
const AULA_CONFIG = {
  nombre: "Aula Virtual de Capacitación en Electrobombas Sumergibles",
  // Ejemplo: 90 días calendario contando el 02/11/2026 como día 1.
  fechaInicio: "2026-11-02",
  fechaFin: "2027-01-30",
  modulos: [
    {titulo:"Fundamentos de electrobombas sumergibles", descripcion:"Principios de funcionamiento, aplicaciones y tipos de bombas.", youtubeId:"", materialUrl:""},
    {titulo:"Componentes y características técnicas", descripcion:"Motor, impulsor, carcasa, sellos mecánicos, sensores y conexiones.", youtubeId:"", materialUrl:""},
    {titulo:"Tableros eléctricos de control", descripcion:"Elementos de mando, protección, control y automatización.", youtubeId:"", materialUrl:""},
    {titulo:"Operación y mantenimiento", descripcion:"Inspecciones, mantenimiento preventivo, diagnóstico de fallas y buenas prácticas.", youtubeId:"", materialUrl:""},
    {titulo:"Seguridad en trabajos electromecánicos", descripcion:"Riesgos eléctricos, EPP, bloqueo y procedimientos seguros.", youtubeId:"", materialUrl:""}
  ]
};