(() => {
const $=id=>document.getElementById(id), mods=AULA_CONFIG.modulos, key="aulaElectrobombasCompletados";let active=null;
const date=(s,end=false)=>{const [y,m,d]=s.split("-").map(Number);return new Date(y,m-1,d,end?23:0,end?59:0,end?59:0)};
const start=date(AULA_CONFIG.fechaInicio),end=date(AULA_CONFIG.fechaFin,true),now=new Date();
$("period").textContent=`Acceso: ${start.toLocaleDateString("es-PE")} al ${date(AULA_CONFIG.fechaFin).toLocaleDateString("es-PE")}`;
if(now<start||now>end){$("content").classList.add("hidden");$("closed").classList.remove("hidden");$("closedMsg").textContent=now<start?`El aula estará disponible desde el ${start.toLocaleDateString("es-PE")}.`:`El periodo de acceso finalizó el ${date(AULA_CONFIG.fechaFin).toLocaleDateString("es-PE")}.`;}
function completed(){try{return JSON.parse(localStorage.getItem(key)||"[]")}catch{return []}}
function progress(){let n=completed().length,p=Math.round(n/mods.length*100);$("pct").textContent=p+"%";$("bar").style.width=p+"%";$("count").textContent=`${n} de ${mods.length} módulos completados`}
function open(i){active=i;let m=mods[i];$("vnum").textContent="MÓDULO "+String(i+1).padStart(2,"0");$("vtitle").textContent=m.titulo;$("vdesc").textContent=m.descripcion;$("video").innerHTML="";
if(m.youtubeId&&/^[\w-]{11}$/.test(m.youtubeId)){let f=document.createElement("iframe");f.src="https://www.youtube-nocookie.com/embed/"+encodeURIComponent(m.youtubeId);f.title=m.titulo;f.allow="accelerometer; autoplay; encrypted-media; picture-in-picture; web-share";f.allowFullscreen=true;$("video").append(f)}else{$("video").innerHTML='<div class="placeholder">▶<p>Agrega el ID del video de YouTube en <code>config.js</code>.</p></div>'}
$("rlink").classList.toggle("hidden",!m.materialUrl);if(m.materialUrl)$("rlink").href=m.materialUrl;$("rtext").textContent=m.materialUrl?"Consulta el material complementario del módulo.":"Puedes incorporar documentos PDF y enlaces de consulta.";
let done=completed().includes(i);$("done").textContent=done?"✓ Módulo completado":"Marcar módulo como completado ✓";$("done").classList.toggle("finished",done);$("modules").classList.add("hidden");$("viewer").classList.remove("hidden");$("viewer").scrollIntoView({behavior:"smooth"});}
document.querySelectorAll("[data-i]").forEach(b=>b.addEventListener("click",()=>open(Number(b.dataset.i))));
$("back").onclick=()=>{$("viewer").classList.add("hidden");$("modules").classList.remove("hidden");$("modules").scrollIntoView({behavior:"smooth"})};
$("done").onclick=()=>{let a=completed(),i=a.indexOf(active);if(i>=0)a.splice(i,1);else a.push(active);localStorage.setItem(key,JSON.stringify(a));progress();open(active)};
progress();
})();